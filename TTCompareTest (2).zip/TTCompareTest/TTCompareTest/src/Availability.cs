﻿using System;

namespace TTCompare
{
	public enum Availability
	{
		N,
		Y,
		M
	}
}