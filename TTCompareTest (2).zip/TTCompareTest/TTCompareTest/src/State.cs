﻿using System;

namespace TTCompare
{
	public enum State
	{
		Main,
		Manage,
		Compare,
		Back,
		Exit
	}
}

